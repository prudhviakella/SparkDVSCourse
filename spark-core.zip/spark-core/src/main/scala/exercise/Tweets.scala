package exercise

import org.apache.spark.{SparkConf, SparkContext}

case class Tweet(tweet_id: String, retweet: String, timestmp: String, source: String, text: String, retweet_count:Int)

object Tweets extends App{

  def parseTweet(text: String): String = {
    //define a regex pattern to match "@username"
    val PATTERN = """(?<=^|(?<=[^a-zA-Z0-9-_\.]))@([A-Za-z]+[A-Za-z0-9]+)""".r
    val res = PATTERN.findFirstMatchIn(text)
    if (res.isEmpty) {
      //throw new RuntimeException("Cannot parse tweet:" + text)
      "NA"
    }
    else {
      //return the username
      val m = res.get
      m.group(1)
    }
  }

  val conf = new SparkConf()
    .setMaster("local")
    .setAppName("Tweets")

  val session = new SparkContext(conf)
  //sc.textFile("data/tweets.csv").map(s => s.split(",")).map(s => Tweet(s(0), s(3), s(5), s(6), s(7))).take(5).foreach(println)
  val tweets = session
    .textFile("/home/cloudera/projects/spark-core/src/main/resources/tweets.csv")
    .map(s => s.split(","))
    .map(s => Tweet(s(0), s(3), s(5), s(6), s(7),0))


  val top10tweets = tweets
      .map(s=> (s.text,if(s.retweet == null)0 else 1))
      .reduceByKey(_+_)
      .map(x=>(x._2,x._1))
      .sortByKey()
      .top(10)
      .map(x=>(x._2,x._1))

  val top10Users = tweets
    .map(x=>(parseTweet(x.text),1))
    .filter(_._1 != "NA")
    .reduceByKey(_+_)
    .map(x=>(x._2,x._1))
    .sortByKey()
    .top(10)
    .map(x=>(x._2,x._1))

  top10Users.foreach(println)
  session.stop()
}
