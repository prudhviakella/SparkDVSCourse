package org.training.spark.apiexamples.discount

object Understanding extends App{

  case class Sales(transid:Int,Customerid:Int,Itemid:Int,Itemamount:Double)

  val aRecord = "111,1,333,400.0"

  val aRecordArray = aRecord.split(",")

  val aRecordTupple = (aRecordArray(0),aRecordArray(1),aRecordArray(2),aRecordArray(3))

  val transcid = aRecordTupple._1 + 1

  println(transcid)

  val aSalesRecord = Sales(aRecordArray(0).toInt,
    aRecordArray(1).toInt,
    aRecordArray(2).toInt,
    aRecordArray(3).toDouble)
  println(aSalesRecord.transid + 1)




  //Schema-> Nameoffield + datatype


}
