package org.training.spark.apiexamples.serialization


class MalformedRecordException extends Exception{
}
