package org.training.spark.apiexamples.advanced;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

public class SerialTest implements Serializable {
    int a;
}

class Deserializeimple {
    public static void main(String args[]) throws IOException,ClassNotFoundException{
        //de-Serialization
        FileInputStream fsi = new FileInputStream("/home/cloudera/projects/SparkProject_V2/object/serial.sz");
        ObjectInputStream ois = new ObjectInputStream(fsi);
        SerialTest st1 = (SerialTest)ois.readObject();
        System.out.println(st1.a);
    }
}
