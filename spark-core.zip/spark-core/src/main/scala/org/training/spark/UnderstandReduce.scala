package org.training.spark

object UnderstandReduce extends App{
  val aList = List(1,2,3,5)
  aList.reduce((x,y)=>x+y)
}
